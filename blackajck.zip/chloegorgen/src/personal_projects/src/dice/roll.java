package dice;
import java.util.Random;

public class roll {
    //returns a random number between 1 and 6
        public void main(String[] args) {
            Random rand = new Random();
            int n = rand.nextInt(6) + 1;
            System.out.println("you have rolled a: " + n);
        }



}
