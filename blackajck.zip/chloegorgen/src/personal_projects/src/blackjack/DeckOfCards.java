package blackjack;


import java.security.SecureRandom;

public class DeckOfCards extends Card{
    private final Card[] deck;
    private int currentCard; //index of the next card to be dealt

    /**
     * Constructor to build deck of cards
     *
     */

    public DeckOfCards(String suit, String face, int value) {
        super(suit, face, value);

        String[] faces = {"2","3","5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
        String[] suits = {"diamonds", "clubs", "hearts", "spades"};

        deck = new Card[52];
        currentCard = 0;

        for (int s = 0; s < 4; s++) {
            for (int f = 0; f < 13; f++) {
                deck[(f + (s*13))] = new Card(
                        suits[s], //calls the suits array to get the name of the suit
                        faces[f], //calls rhe faces array to get the value of the face
                        f+2); //the card at index 0 is 2, the card at index 1 is 3, etc.
            }
        }
    }

    public void main (String[] args) {
        shuffleDeck();
        draw();
    }

    /**
     * The shuffleDeck method will allow the order of the cards to be randomized for a game
     *
     */
    public void shuffleDeck() {
        currentCard = 0;
        //for each card in the deck, pick another random card and swap them
        SecureRandom random = new SecureRandom();

        for (int n = 0; n < deck.length; n++) {
            int m = random.nextInt(52);

            //swap cards
            Card temp = deck[n];
            deck[n] = deck[m];
            deck[m] = temp;

        }
    }

    /**
     * draw() will return the first card in the array
     * will be used for incrementing cards in the game and dealing cards at the beginning of the game
     *
     * @return top card if deck has cards, null if deck is empty
     */

    public Card draw() {
        if (currentCard < deck.length) {
            return deck[currentCard++];
        }
        return null;
    }
}
