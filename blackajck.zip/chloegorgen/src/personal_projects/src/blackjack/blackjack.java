package blackjack;

import java.util.Scanner;

public class blackjack extends DeckOfCards{
    public Card[] player = null;
    public Card[] dealer = null;
    public int dealerCount = tally(dealer);
    public int playerCount = tally(player);
    public double bet;

    /**
     * Constructor to build deck of cards
     *
     * @param suit
     * @param face
     * @param value
     */
    public blackjack(String suit, String face, int value) {
        super(suit, face, value);
    }


    public void main(String[] args) {

        //player places their bet
        bets();
        //the cards are shuffled
        shuffleDeck();
        //deal card to player using draw method from DeckOfCards and iterate
        deal(player);
        System.out.println("The player has: " + player);
        //deal card to dealer and the player can see how many points the dealer have
        deal(dealer);
        System.out.println("The dealer has: " + dealer);
        //deal another card to player and the player can see how many points the they have
        deal(player);
        System.out.println("The player has: " + player);
        //deal other card to dealer but the player can't see how many points the dealer has
        deal(dealer);
        System.out.println("Second card dealt to dealer");

        //checkCards will determine if the player has a bust or if they have 21
        checkPlayerCards();

    }
    public double bets() {
        Scanner myObj = new Scanner(System.in);
        System.out.println("How much would you like to bet?");
        int bet = myObj.nextInt();
        if ( Double.compare(2, bet) < 0) {
            System.out.println("Please bet more than $2.00");
            System.out.println("How much would you like to bet? Enter in form 00.00");
        } else if (Double.compare(bet, 500) < 0) {
            System.out.println("Please bet less that $500");
            System.out.println("How much would you like to bet? Enter in form 00.00");
        }
        System.out.println("You have bet: " + bet);
        return bet;
    }

    /**deal needs needs to update the playerHand or dealerHand depending on whose is called
     *if ace is called, the player/dealer count has to store two numbers and the one closer to 21 under 21 will be used in the final count
     *
     */
    public void deal(Card[] hand){
         addX(draw(), hand);
    }

    public void checkPlayerCards() {
        Scanner playerResponse = new Scanner(System.in);
        if (playerCount == 21) {
            System.out.println("Player wins!");
            bet = bet * 1.5;
        }
        else if (playerCount > 21) {
            System.out.println("Player Loses: player busts");
            bet = 0;
        }
        else if (playerCount < 21){
            System.out.println("Do you want another card? Respond: HIT or STAND. You currently have: " + playerCount);
            String resp = playerResponse.nextLine();
            while (resp.equals("HIT")) {
                deal(player);
                checkPlayerCards();
            }
            compare();
            gameOver();
        }
    }

    public double compare() {
        if (dealerCount >= 21) {
            System.out.println("Player wins! Dealer busts");
            bet = bet * 2;
        } else if (dealerCount >= playerCount) {
            System.out.println("Player Loses: dealer count (" + dealerCount + ") greater than player count (" + playerCount + ")");
            System.out.println("Dealer Count: " + dealerCount);

            bet = 0;
        } else {
            System.out.println("Player wins! Player count (" + playerCount + ") greater than dealer count (" + dealerCount + ")");
        }
        return bet;
    }

    /**
     *
     *
     * @param p array of cards in player or dealers hand to be tallied
     * @return int of the points earned by the cards in the players hand. Because "ace" can be either 1 or 11 depending on which is more
     * advantageous, two tallies are calculated and the max is returned unless the max would create a "bust", then the min is returned
     */
    public int tally(Card[] p) {
        int c = 0;
        int t1 = 0;
        int t2 = 0;
        for (int i = 0; i < p.length; i++) {
            Card current = p[i];
            String f = current.getFace();
            int value = current.getFaceValue();
            if (value > 10) {
                //all face cards except ace has a point value of 10
                //if the current card is not ace
                if ( value != 14) {
                    t1 += 10;
                    t2 += 10;
                    //if the current card is ace, can be either 1 or 11
                } else {
                    t1 += 1;
                    t2 += 11;
                }
            } else {
                t1 += value;
                t2 += value;
            }
            if (Math.max(t1, t2) <= 21){
                c = Math.max(t1, t2);
            }
            c = Math.min(t1,t2);
        }
        return c;
    }

    /**
     * add method adds a new card to the hand after each deal
     *
     * @param c card dealt to be added to the array
     * @param a array of cards in the players hand
     * @return new array with the new card added at the end of the array
     */
    public Card[] addX(Card c, Card[] a) {
        Card[] newArr = null;
        for (int i = 0; i < a.length; i++ ) {
            newArr[i] = a[i];
        }
        newArr[a.length+1] = c;
        return newArr;
    }


    public void gameOver() {
        System.out.println("Game Over! Money won: " + bet);
    }


}

