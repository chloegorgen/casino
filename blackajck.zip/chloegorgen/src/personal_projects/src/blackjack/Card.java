package blackjack;

public class Card {
    private final String faceName, suit;
    private final int faceValue;

    /**
     *This constructor builds cards for the card class
     *
     * @param suit "spades", "clubs", "hearts", "diamonds"
     * @param face 2, 3, 4, 5, 6, 7, 8, 9, 10, Jack, Queen, King, Ace
     * @param value 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14
     */

    public Card(String suit, String face, int value) {
        this.suit = suit;
        faceName = face;
        faceValue = value;
    }


    /**
     * getFaceValue() and toString() return the face value and a line explaining the type of card
     *
     * @return face value, face name
     */

    public int getFaceValue() {
        return faceValue;
    }

    public String getFace() {
        return faceName;
    }
    public String toString() {
        return faceName + " of " + suit;
    }
}
